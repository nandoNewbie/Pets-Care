
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Rendra Dwi Prasetyo - 2602199960
 */
public class patient_channel extends javax.swing.JFrame {

    /**
     * Creates new form Channel
     */
    public patient_channel() 
    {
        initComponents();
    }
     
    int id;
    String role;
    int newid;
    
    public patient_channel(int id, String role) 
    {
        initComponents();
       
        this.id =id;
        this.role = role;
        
        newid = id;
        
        Connect();
        AutoID();
        LoadDoctor();
        LoadPatient();
        channel_tables();        
        
        txtdoctor.setSelectedIndex(-1);
        txtpatient.setSelectedIndex(-1);
        
        delete.setEnabled(false);
        Cancel.setVisible(false);
    }
     
    
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
           
    String status;
    String chno;
        
    public class Doctor       
    {
        String id;
        String name;
            
        
        public Doctor (String id, String name)
        {
            this.id = id;
            this.name = name;
            txtdate.setDate(new java.util.Date());
            
            txtdoctor.addActionListener((ActionEvent e) -> {
                Doctor selectedDoctor = (Doctor) txtdoctor.getSelectedItem();
                if (selectedDoctor != null) {
                    SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
                    String selectedDate = dateformat.format(txtdate.getDate());
                    loadAvailableTimes(selectedDoctor.id, selectedDate);
                } else {
                    System.out.println("Selected Doctor is null.");
                }   });
                
            txtdate.addPropertyChangeListener((java.beans.PropertyChangeEvent evt) -> 
            {
                   if ("date".equals(evt.getPropertyName())) {
        Doctor selectedDoctor = (Doctor) txtdoctor.getSelectedItem();
        if (selectedDoctor != null) {
            System.out.println("Selected Doctor ID: " + selectedDoctor.id);
            SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
            String selectedDate = dateformat.format(txtdate.getDate());
            System.out.println("Selected Date: " + selectedDate);
            loadAvailableTimes(selectedDoctor.id, selectedDate);
        } else {
           System.out.println("Selected Doctor is null.");   
        }
    } else {
        System.out.println("Property Change Event not related to date.");
    }
                });
        }
            
        public String toString()
        {
            return name;
        }
            
    }
        
        
    public class Patient
    {
        String id;
        String name;
        
        public Patient (String id, String name)
        {
            this.id = id;
            this.name = name;
        }
            
        public String toString()
         {
            return name;
        }       
    }
        
        
    public void LoadPatient()
    {
        try 
        {
            pst = con.prepareStatement("select * from patient WHERE log_id = ?");
            pst.setInt(1, newid);
            rs = pst.executeQuery();
            txtpatient.removeAll();
            
            while(rs.next())
            {
                txtpatient.addItem(new Patient(rs.getString(1),rs.getString(2)));
            }
            
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Channel.class.getName()).log(Level.SEVERE, null, ex);
        }
  
    }
       
        
    // Method untuk memuat opsi jam berdasarkan dokter dan tanggal
    public void loadAvailableTimes(String doctorId, String selectedDate) {
        try {
           // Membersihkan atau mengosongkan opsi jam sebelum menambahkan yang baru
            time.removeAllItems();

            // Query untuk mendapatkan jam yang sudah diambil oleh dokter pada tanggal tertentu
            PreparedStatement pst = con.prepareStatement("SELECT jam FROM channel WHERE doctorname = ? AND date = ?");
            pst.setString(1, doctorId);
            pst.setString(2, selectedDate);

            ResultSet rs = pst.executeQuery();

            ArrayList<String> takenTimes = new ArrayList<>();

            while (rs.next()) {
                takenTimes.add(rs.getString("jam"));
            }

            // Membuat list jam dari 08:00 hingga 20:00 sebagai opsi default
            String[] defaultTimes = { "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00"};

            // Tambahkan semua opsi jam ke combo box time
            for (String timeSlot : defaultTimes) {
                if (!takenTimes.contains(timeSlot)) {
                    time.addItem(timeSlot);
                }
            }

        } catch (SQLException ex) {
            Logger.getLogger(patient_channel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }       
        
        
    public void LoadDoctor()
    {
        try {
            pst = con.prepareStatement("select * from Doctor WHERE status = 'Active'");
            rs = pst.executeQuery();
            txtdoctor.removeAll();
            
            while(rs.next())
            {
                txtdoctor.addItem(new Doctor(rs.getString(1),rs.getString(2)));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Channel.class.getName()).log(Level.SEVERE, null, ex);
        }       
    }
                 
        
        public void Connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/doctor_care","root","");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
        
        public void AutoID()
    {
        try {
            Statement s = con.createStatement();
            rs = s.executeQuery("select MAX(channelno) from channel");
            rs.next();
            rs.getString("MAX(channelno)"); 
            
            if(rs.getString("MAX(channelno)") == null)
            {
                lblchno.setText("CH001");
            }
            else
            {
                long id = Long.parseLong(rs.getString("MAX(channelno)").substring(2,rs.getString("MAX(channelno)").length()));
                id++;
                lblchno.setText("CH"+String.format("%03d", id));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Doctor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtdoctor = new javax.swing.JComboBox();
        txtpatient = new javax.swing.JComboBox();
        lblchno = new javax.swing.JLabel();
        txtdate = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        time = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        channel_table = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        Cancel = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 51, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Make Appointment ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 12), new java.awt.Color(255, 255, 153))); // NOI18N

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Channel No");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Doctor Name");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Patient Name");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Channel Date");

        txtdoctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdoctorActionPerformed(evt);
            }
        });

        lblchno.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblchno.setForeground(new java.awt.Color(255, 255, 204));
        lblchno.setText(" ");

        jButton1.setText("Add");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        delete.setText("Delete");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        jButton4.setText(">");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        time.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "19:00", "20:00" }));
        time.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timeActionPerformed(evt);
            }
        });

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Time");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(delete))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addGap(81, 81, 81))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(73, 73, 73)))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lblchno, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(txtdoctor, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(1, 1, 1)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(106, 106, 106))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel5)
                                            .addGap(72, 72, 72))))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtpatient, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtdate, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lblchno))
                .addGap(46, 46, 46)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtdoctor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtpatient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(43, 43, 43)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(txtdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(delete))
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 83, 350, 450));

        channel_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Channel No", "Doctor Name", "Patient Name", "Date", "Time"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        channel_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                channel_tableMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                channel_tableMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(channel_table);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, 510, 444));

        jButton3.setText("Back");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 550, -1, -1));

        jLabel8.setFont(new java.awt.Font("Sitka Banner", 3, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 255, 102));
        jLabel8.setText("Appointment Registation");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 334, -1));
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, -1, 60));
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, -1, 60));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/1AWallpaper.jpg"))); // NOI18N
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 10, 640, 60));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/1AWallpaper.jpg"))); // NOI18N
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 640, 60));

        Cancel.setText("Cancel");
        Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelActionPerformed(evt);
            }
        });
        getContentPane().add(Cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 550, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
         this.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        chno = lblchno.getText();
        Doctor d = (Doctor) txtdoctor.getSelectedItem();
        Patient p = (Patient) txtpatient.getSelectedItem();
        String ptime = time.getSelectedItem().toString();;
        SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
        String date = dateformat.format(txtdate.getDate());
        
        try 
        {
            pst = con.prepareStatement("insert into channel(channelno,doctorname,patientname,roomno,date,jam,log_id,status) values(?,?,?,?,?,?,?,?)");
            pst.setString(1, chno);
            pst.setString(2, d.id);
            pst.setString(3, p.id);
            pst.setString(4, "0");
            pst.setString(5, date);
            pst.setString(6, ptime);
            pst.setInt(7, newid);
            pst.setString(8, "pending");
            
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(this,"Channel Added"); 
            
            AutoID();
            txtdoctor.setSelectedIndex(-1);
            txtdoctor.setSelectedIndex(-1);

            channel_tables();
//          this.setVisible(false);
//          new patient_channel(newid,role).setVisible(true);

        } catch (SQLException ex) {
            Logger.getLogger(Patient.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void channel_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_channel_tableMouseClicked
        DefaultTableModel model = (DefaultTableModel) channel_table.getModel();
        int selectedRowIndex = channel_table.getSelectedRow();

        delete.setEnabled(true);
        Cancel.setVisible(true);
                
        // Memasukkan nilai dari tabel ke komponen-komponen yang sesuai
        lblchno.setText(model.getValueAt(selectedRowIndex, 0).toString()); // Channel No
//        txtdoctor.setSelectedItem(model.getValueAt(selectedRowIndex, 1)); // Doctor Name
//        txtpatient.setSelectedItem(model.getValueAt(selectedRowIndex, 2)); // Patient Name

        // Mengatur nilai tanggal pada JDateChooser
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try {
            java.util.Date date = formatter.parse(model.getValueAt(selectedRowIndex, 3).toString());
            txtdate.setDate(date);
        } catch (ParseException ex) {
            Logger.getLogger(patient_channel.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Mengatur nilai jam pada JComboBox time
        String selectedTime = model.getValueAt(selectedRowIndex, 4).toString(); // Jam
        time.setSelectedItem(selectedTime);

    }//GEN-LAST:event_channel_tableMouseClicked

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        chno = lblchno.getText();
        
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure want to cancel?", "Exit confirmation", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
            pst = con.prepareStatement("DELETE from channel WHERE channelno = ?");
            pst.setString(1, chno);        
            pst.executeUpdate();


            JOptionPane.showMessageDialog(this,"Channel Deleted"); 
            
            AutoID();
            txtdoctor.setSelectedIndex(-1);
            txtpatient.setSelectedIndex(-1);
            delete.setEnabled(false);
            Cancel.setVisible(false);
            channel_tables();

            } catch (SQLException ex) {
                Logger.getLogger(Patient.class.getName()).log(Level.SEVERE, null, ex);
            }
        }               
    }//GEN-LAST:event_deleteActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        new doctor_list(newid,role).setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void txtdoctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdoctorActionPerformed

    }//GEN-LAST:event_txtdoctorActionPerformed

    private void timeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timeActionPerformed

    }//GEN-LAST:event_timeActionPerformed

    private void channel_tableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_channel_tableMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_channel_tableMouseReleased

    private void CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelActionPerformed


            AutoID();
            txtdoctor.setSelectedIndex(-1);
            txtpatient.setSelectedIndex(-1);
            
        
        
        channel_table.clearSelection();
        delete.setEnabled(false);
        Cancel.setVisible(false);
    }//GEN-LAST:event_CancelActionPerformed

    public void channel_tables()
    {
        try {
            pst = con.prepareStatement("select * from channel WHERE log_id = ?");
           pst.setInt(1, newid);
            rs = pst.executeQuery();
            ResultSetMetaData Rsm = rs.getMetaData();
            int c;
            c = Rsm.getColumnCount();
            
            DefaultTableModel df = (DefaultTableModel)channel_table.getModel();
            df.setRowCount(0);
            
            while(rs.next())
            {
               Vector v2 = new Vector();
               
               for (int i = 1; i<=c; i++)
               {
                   v2.add(rs.getString("channelno"));
                   v2.add(rs.getString("doctorname"));
                   v2.add(rs.getString("patientname"));
                   v2.add(rs.getString("date"));
                   v2.add(rs.getString("jam"));
               }
               
               df.addRow(v2);
               
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Doctor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Channel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Channel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Channel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Channel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Channel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancel;
    private javax.swing.JTable channel_table;
    private javax.swing.JButton delete;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblchno;
    private javax.swing.JComboBox<String> time;
    private com.toedter.calendar.JDateChooser txtdate;
    private javax.swing.JComboBox txtdoctor;
    private javax.swing.JComboBox txtpatient;
    // End of variables declaration//GEN-END:variables
}
