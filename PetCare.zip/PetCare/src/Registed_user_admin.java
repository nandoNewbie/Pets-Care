import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Rendra Dwi Prasetyo - 2602199960
 */
public class Registed_user_admin extends javax.swing.JFrame {

    /**
     * Creates new form Registed_user_admin
     */
    
    int id;
    String userole;
    String name;
    
    public Registed_user_admin() {
        initComponents();

        
    }
        public Registed_user_admin(int id, String userole) {
        initComponents();
        
        this.id = id;
        this.userole = userole;
        Connect();
        AutoID();
        TableData();
        txtrole.setSelectedIndex(-1);
        update.setEnabled(false);
    }

    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
    public void Connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/doctor_care","root","");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        TableData();
    }
    

    public void TableData() {
    try {
        pst = con.prepareStatement("SELECT * FROM user");
        rs = pst.executeQuery();
        ResultSetMetaData Rsm = rs.getMetaData();
        int c;
        c = Rsm.getColumnCount();
            
        DefaultTableModel df = (DefaultTableModel)jTable1.getModel();
        df.setRowCount(0);

             while(rs.next())
            {
               Vector v2 = new Vector();
               
               for (int i = 1; i<=c; i++)
               {
                   v2.add(rs.getInt("id"));
                   v2.add(rs.getString("name"));
                   v2.add(rs.getString("userrname"));
                   v2.add(rs.getString("password"));
                   v2.add(rs.getString("Role"));
               }
               df.addRow(v2);               
            }

    } catch (SQLException ex) {
        Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
    }
}
    
public void AutoID() {
    try {
        Statement statement = con.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT COALESCE(MAX(id), 0) AS max_id FROM user");
        
        if (resultSet.next()) {
            int id = resultSet.getInt("max_id") + 1;
            labelID.setText(String.valueOf(id));
        }
    } catch (SQLException ex) {
        Logger.getLogger(Patient.class.getName()).log(Level.SEVERE, null, ex);
    }
}

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Bar_atas = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        Delete = new javax.swing.JButton();
        panel_object = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        add = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        txtusername = new javax.swing.JTextField();
        txtpassword = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        txtrole = new javax.swing.JComboBox<>();
        update = new javax.swing.JButton();
        labelID = new javax.swing.JLabel();
        Cancel = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        Bar_atas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Bar_atasMouseEntered(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("User Registation");

        jButton4.setText("Back");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        Delete.setText("Delete");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Bar_atasLayout = new javax.swing.GroupLayout(Bar_atas);
        Bar_atas.setLayout(Bar_atasLayout);
        Bar_atasLayout.setHorizontalGroup(
            Bar_atasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Bar_atasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Bar_atasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Bar_atasLayout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(Bar_atasLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(Delete)
                        .addGap(27, 27, 27)
                        .addComponent(jButton4)
                        .addGap(242, 242, 242))))
        );
        Bar_atasLayout.setVerticalGroup(
            Bar_atasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Bar_atasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Bar_atasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(Delete))
                .addGap(16, 16, 16))
        );

        jPanel2.setBackground(new java.awt.Color(0, 51, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nama :");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Username :");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, -1, -1));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Password :");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, -1));

        add.setBackground(new java.awt.Color(204, 204, 204));
        add.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        add.setText("Add");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        jPanel2.add(add, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 420, 80, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Create New User");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 310, 80));

        txtname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnameActionPerformed(evt);
            }
        });
        jPanel2.add(txtname, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 150, 230, -1));
        jPanel2.add(txtusername, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 210, 230, -1));
        jPanel2.add(txtpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, 230, -1));

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Role :");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, -1, -1));

        txtrole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Doctor", "Patient" }));
        txtrole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtroleActionPerformed(evt);
            }
        });
        jPanel2.add(txtrole, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 350, 230, -1));

        update.setBackground(new java.awt.Color(204, 204, 204));
        update.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        jPanel2.add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 420, 80, 30));

        labelID.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelID.setForeground(new java.awt.Color(255, 255, 255));
        labelID.setText("LABEL ID");
        jPanel2.add(labelID, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 90, 30));

        Cancel.setText("Cancel");
        Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelActionPerformed(evt);
            }
        });
        jPanel2.add(Cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 470, 80, -1));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("ID :");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "log_id", "Nama", "Username", "Password", "Role"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout panel_objectLayout = new javax.swing.GroupLayout(panel_object);
        panel_object.setLayout(panel_objectLayout);
        panel_objectLayout.setHorizontalGroup(
            panel_objectLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_objectLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 826, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(286, Short.MAX_VALUE))
        );
        panel_objectLayout.setVerticalGroup(
            panel_objectLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_objectLayout.createSequentialGroup()
                .addGroup(panel_objectLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 505, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 33, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel_object, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Bar_atas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Bar_atas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel_object, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowActivated

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
         Connect();
         
        String no = labelID.getText(); 
        String name = txtname.getText();
        String username = txtusername.getText();
        String password = txtpassword.getText();
        String Role = txtrole.getSelectedItem().toString();

        try {
            // Lakukan pemeriksaan apakah username sudah terdaftar sebelumnya
            PreparedStatement checkUsername = con.prepareStatement("SELECT * FROM user WHERE userrname = ?");
            checkUsername.setString(1, username);
            ResultSet resultSet = checkUsername.executeQuery();

            if (resultSet.next()) {
                // Jika username sudah terdaftar, tampilkan pesan kesalahan
                JOptionPane.showMessageDialog(this, "Username already exists. Please choose another username.");
            } else {
                // Jika username belum terdaftar, lakukan proses pemasukan data ke dalam database
                pst = con.prepareStatement("insert into user(id, name, userrname, password, Role) values(?,?,?,?,?)");
                pst.setString(1, no);
                pst.setString(2, name);
                pst.setString(3, username);
                pst.setString(4, password);
                pst.setString(5, Role);
                pst.executeUpdate();

                JOptionPane.showMessageDialog(this, "User Inserted");

                AutoID();
                txtname.setText("");
                txtusername.setText("");
                txtpassword.setText("");
                txtrole.setSelectedIndex(-1);
                TableData();
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_addActionPerformed

    private void txtnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnameActionPerformed

    private void txtroleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtroleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtroleActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        // TODO add your handling code here:
          // Dapatkan baris yang dipilih dari jTable1
    int row = jTable1.getSelectedRow();
    
    if (row == -1) {
        JOptionPane.showMessageDialog(this, "Pilih baris untuk dihapus");
    } else {
        // Dapatkan nilai ID dari baris yang dipilih
        String id = jTable1.getModel().getValueAt(row, 0).toString();
        
        try {
            // Hapus data berdasarkan ID dari database
            pst = con.prepareStatement("DELETE FROM user WHERE id = ?");
            pst.setString(1, id);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data telah dihapus");
            AutoID(); // Update kembali ID setelah penghapusan
            TableData(); // Tampilkan ulang data di jTable1
            update.setEnabled(false);
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }//GEN-LAST:event_DeleteActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();
        add.setEnabled(false);

        // Mendapatkan data dari baris yang diklik
        String id = jTable1.getModel().getValueAt(row, 0).toString();
        String name = jTable1.getModel().getValueAt(row, 1).toString();
        String username = jTable1.getModel().getValueAt(row, 2).toString();
        String password = jTable1.getModel().getValueAt(row, 3).toString();
        String role = jTable1.getModel().getValueAt(row, 4).toString();

        // Menampilkan data ke field yang sesuai
        labelID.setText(id);
        update.setEnabled(true);
        txtname.setText(name);
        txtusername.setText(username);
        txtpassword.setText(password);
        txtrole.setSelectedItem(role);
    }//GEN-LAST:event_jTable1MouseClicked

    private void Bar_atasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Bar_atasMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_Bar_atasMouseEntered

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
    // Dapatkan baris yang dipilih dari jTable1
    int row = jTable1.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(this, "Pilih baris untuk diperbarui");
    } else {
        // Dapatkan nilai ID dari baris yang dipilih
        String id = jTable1.getModel().getValueAt(row, 0).toString();
        
        // Ambil nilai dari field input
        String name = txtname.getText();
        String username = txtusername.getText();
        String password = txtpassword.getText();
        String Role = txtrole.getSelectedItem().toString();

        try {
            // Lakukan update berdasarkan ID dari database
            pst = con.prepareStatement("UPDATE user SET name=?, userrname=?, password=?, Role=? WHERE id=?");
            pst.setString(1, name);
            pst.setString(2, username);
            pst.setString(3, password);
            pst.setString(4, Role);
            pst.setString(5, id);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data telah diperbarui");
            AutoID(); // Update kembali ID setelah perubahan
            TableData(); // Tampilkan ulang data di jTable1
            update.setEnabled(false);
            
            update.setEnabled(false);
            txtname.setText("");
            txtusername.setText("");
            txtpassword.setText("");
            txtrole.setSelectedIndex(-1);
            
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }//GEN-LAST:event_updateActionPerformed

    private void CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelActionPerformed
   
                AutoID();
                jTable1.clearSelection();
                update.setEnabled(false);
                txtname.setText("");
                txtusername.setText("");
                txtpassword.setText("");
                txtrole.setSelectedIndex(-1);
   
    }//GEN-LAST:event_CancelActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registed_user_admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registed_user_admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registed_user_admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registed_user_admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registed_user_admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Bar_atas;
    private javax.swing.JButton Cancel;
    private javax.swing.JButton Delete;
    private javax.swing.JButton add;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelID;
    private javax.swing.JPanel panel_object;
    private javax.swing.JTextField txtname;
    private javax.swing.JPasswordField txtpassword;
    private javax.swing.JComboBox<String> txtrole;
    private javax.swing.JTextField txtusername;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
