import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class Main extends javax.swing.JFrame 
{

    /**
     * Creates new form Main
     */
    public Main() 
    {
        initComponents();
    }
    
    Connection con;
    PreparedStatement pst;
    int idd;
    String userole;
    int newid;
    String uname;

    public void Connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/doctor_care","root","");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
                    
    private boolean checkDataExists(int id) 
    {
    Connect();
    boolean dataExists = false;
    try {           
        if(userole.equals("Patient"))
        {
            String query = "SELECT COUNT(*) FROM patient WHERE log_id = ?";
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();

            if(resultSet.next()) {
                int count = resultSet.getInt(1);
                if(count > 0) {
                    dataExists = true;
                    }
                }  
        }

        else if(userole.equals("Doctor"))
        {
        String query = "SELECT COUNT(*) FROM doctor WHERE log_id = ?";
        PreparedStatement statement = con.prepareStatement(query);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()) {
                int count = resultSet.getInt(1);
                if(count > 0) {
                    dataExists = true;
                }
            }
        }

        // Tutup statement, resultSet, dan koneksi ke database
        } catch (SQLException ex) {
        // Tangani kesalahan koneksi atau query
        ex.printStackTrace();
        }
            return dataExists;
    }       
                    
    
    public Main(int id, String username, String role) {
        initComponents();
        
        this.uname = username;
        jLabel5.setText(uname);
        
        this.userole = role;
        jLabel6.setText(userole);
        
        this.newid = id;
        
        idd = newid;
        
        Color disabledColor = new Color(192, 192, 192);
        
        userole = jLabel6.getText();
        
        if(userole.equals("Doctor"))
        {
            create_channel.setVisible(false);
            user_admin.setVisible(false);
            view_doctor.setVisible(false);
            registed_doctor.setVisible(false);
            jPanel59.setVisible(false);
            jPanel99.setVisible(false);
            jPanel107.setVisible(false);
            jPanel43.setVisible(false);
            jLabel20.setVisible(false);


                boolean dataExists = checkDataExists(idd); // Mengembalikan true jika data ada

                if(!dataExists) {
                    View_appointment.setEnabled(false);
                    registed_patient.setEnabled(false);
                }
                else
                {
                    View_appointment.setEnabled(true);
                    registed_patient.setEnabled(true);
                }
                
                    // Mengambil status dari database
            try {
                String getStatusQuery = "SELECT status FROM doctor WHERE log_id = ?";
                PreparedStatement getStatusStatement = con.prepareStatement(getStatusQuery);
                getStatusStatement.setInt(1, id);
                ResultSet statusResultSet = getStatusStatement.executeQuery();

                if (statusResultSet.next()) {
                    String status = statusResultSet.getString("status");
                    // Set nilai default dari jComboBox1 sesuai status yang didapat dari database
                    jComboBox1.setSelectedItem(status);
                }
            } catch (SQLException ex) {
                // Tangani kesalahan koneksi atau query
                ex.printStackTrace();
            }          
        }
        else if (userole.equals("Patient"))
        {
            Connect();
            regist_doctor.setVisible(false);
            registed_patient.setVisible(false);
            View_appointment.setVisible(false);
            user_admin.setVisible(false);
            registed_doctor.setVisible(false);
            jComboBox1.setVisible(false);
            
            jPanel83.setVisible(false);
            jPanel35.setVisible(false);
            jPanel51.setVisible(false);
            jPanel43.setVisible(false);
                      
            
            boolean dataExists = checkDataExists(idd); // Mengembalikan true jika data ada

                if(!dataExists) {
                    create_channel.setEnabled(false);
                    view_doctor.setEnabled(false);
                    
                    jPanel99.setBackground(disabledColor); 
                    jPanel107.setBackground(disabledColor); 
                }
                else
                {
                    create_channel.setEnabled(true);
                    view_doctor.setEnabled(true);
                }
        }
        else
        {

            regist_doctor.setVisible(false);
            view_doctor.setVisible(false);
            create_channel.setVisible(false);
            View_appointment.setVisible(false);

            jComboBox1.setVisible(false);
            jButton5.setVisible(false);
            
            
            jPanel59.setVisible(false);
            jPanel99.setVisible(false);
            jPanel107.setVisible(false);
            jPanel83.setVisible(false);
            jLabel16.setVisible(false);
        }
        
        
 

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel10 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel11 = new javax.swing.JLabel();
        jPanel59 = new javax.swing.JPanel();
        jPanel60 = new javax.swing.JPanel();
        jPanel61 = new javax.swing.JPanel();
        jPanel62 = new javax.swing.JPanel();
        jPanel63 = new javax.swing.JPanel();
        jPanel64 = new javax.swing.JPanel();
        jPanel65 = new javax.swing.JPanel();
        jPanel66 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        regist_pasien = new javax.swing.JButton();
        jPanel99 = new javax.swing.JPanel();
        jPanel100 = new javax.swing.JPanel();
        jPanel101 = new javax.swing.JPanel();
        jPanel102 = new javax.swing.JPanel();
        jPanel103 = new javax.swing.JPanel();
        jPanel104 = new javax.swing.JPanel();
        jPanel105 = new javax.swing.JPanel();
        jPanel106 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        create_channel = new javax.swing.JButton();
        jPanel107 = new javax.swing.JPanel();
        jPanel108 = new javax.swing.JPanel();
        jPanel109 = new javax.swing.JPanel();
        jPanel110 = new javax.swing.JPanel();
        jPanel111 = new javax.swing.JPanel();
        jPanel112 = new javax.swing.JPanel();
        jPanel113 = new javax.swing.JPanel();
        jPanel114 = new javax.swing.JPanel();
        jPanel115 = new javax.swing.JPanel();
        jPanel116 = new javax.swing.JPanel();
        jPanel117 = new javax.swing.JPanel();
        jPanel118 = new javax.swing.JPanel();
        jPanel119 = new javax.swing.JPanel();
        jPanel120 = new javax.swing.JPanel();
        jPanel121 = new javax.swing.JPanel();
        jPanel122 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        view_doctor = new javax.swing.JButton();
        jPanel83 = new javax.swing.JPanel();
        jPanel84 = new javax.swing.JPanel();
        jPanel85 = new javax.swing.JPanel();
        jPanel86 = new javax.swing.JPanel();
        jPanel87 = new javax.swing.JPanel();
        jPanel88 = new javax.swing.JPanel();
        jPanel89 = new javax.swing.JPanel();
        jPanel90 = new javax.swing.JPanel();
        jPanel91 = new javax.swing.JPanel();
        jPanel92 = new javax.swing.JPanel();
        jPanel93 = new javax.swing.JPanel();
        jPanel94 = new javax.swing.JPanel();
        jPanel95 = new javax.swing.JPanel();
        jPanel96 = new javax.swing.JPanel();
        jPanel97 = new javax.swing.JPanel();
        jPanel98 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        regist_doctor = new javax.swing.JButton();
        jPanel35 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jPanel36 = new javax.swing.JPanel();
        jPanel37 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jPanel39 = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        jPanel41 = new javax.swing.JPanel();
        jPanel42 = new javax.swing.JPanel();
        jPanel67 = new javax.swing.JPanel();
        jPanel68 = new javax.swing.JPanel();
        jPanel69 = new javax.swing.JPanel();
        jPanel70 = new javax.swing.JPanel();
        jPanel71 = new javax.swing.JPanel();
        jPanel72 = new javax.swing.JPanel();
        jPanel73 = new javax.swing.JPanel();
        jPanel74 = new javax.swing.JPanel();
        registed_doctor = new javax.swing.JButton();
        View_appointment = new javax.swing.JButton();
        jPanel51 = new javax.swing.JPanel();
        jPanel52 = new javax.swing.JPanel();
        jPanel53 = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        jPanel55 = new javax.swing.JPanel();
        jPanel56 = new javax.swing.JPanel();
        jPanel57 = new javax.swing.JPanel();
        jPanel58 = new javax.swing.JPanel();
        jPanel75 = new javax.swing.JPanel();
        jPanel76 = new javax.swing.JPanel();
        jPanel77 = new javax.swing.JPanel();
        jPanel78 = new javax.swing.JPanel();
        jPanel79 = new javax.swing.JPanel();
        jPanel80 = new javax.swing.JPanel();
        jPanel81 = new javax.swing.JPanel();
        jPanel82 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        registed_patient = new javax.swing.JButton();
        jPanel43 = new javax.swing.JPanel();
        jPanel44 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jPanel46 = new javax.swing.JPanel();
        jPanel47 = new javax.swing.JPanel();
        jPanel48 = new javax.swing.JPanel();
        jPanel49 = new javax.swing.JPanel();
        jPanel50 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        user_admin = new javax.swing.JButton();
        jPanel123 = new javax.swing.JPanel();
        jPanel124 = new javax.swing.JPanel();
        jPanel125 = new javax.swing.JPanel();
        jPanel126 = new javax.swing.JPanel();
        jPanel127 = new javax.swing.JPanel();
        jPanel128 = new javax.swing.JPanel();
        jPanel129 = new javax.swing.JPanel();
        jPanel130 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        panel_utama = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Rockwell Condensed", 3, 48)); // NOI18N
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 30, 203, -1));

        jPanel1.setBackground(new java.awt.Color(51, 0, 51));
        jPanel1.setToolTipText("");
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator1.setAlignmentY(3.0F);
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 160, 20));

        jLabel11.setFont(new java.awt.Font("Rockwell Condensed", 3, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("MENU");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 120, -1));

        jPanel59.setBackground(new java.awt.Color(0, 81, 120));
        jPanel59.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel60.setBackground(new java.awt.Color(0, 102, 153));
        jPanel60.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel59.add(jPanel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel61.setBackground(new java.awt.Color(0, 102, 153));
        jPanel61.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel62.setBackground(new java.awt.Color(0, 102, 153));
        jPanel62.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel61.add(jPanel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel59.add(jPanel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel63.setBackground(new java.awt.Color(0, 102, 153));
        jPanel63.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel64.setBackground(new java.awt.Color(0, 102, 153));
        jPanel64.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel63.add(jPanel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel65.setBackground(new java.awt.Color(0, 102, 153));
        jPanel65.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel66.setBackground(new java.awt.Color(0, 102, 153));
        jPanel66.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel65.add(jPanel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel63.add(jPanel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel59.add(jPanel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Regist.png"))); // NOI18N
        jPanel59.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 40, 40));

        regist_pasien.setBackground(new java.awt.Color(0, 81, 120));
        regist_pasien.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        regist_pasien.setForeground(new java.awt.Color(255, 255, 255));
        regist_pasien.setText("            Regist Patient");
        regist_pasien.setToolTipText("");
        regist_pasien.setBorderPainted(false);
        regist_pasien.setContentAreaFilled(false);
        regist_pasien.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        regist_pasien.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        regist_pasien.setHideActionText(true);
        regist_pasien.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        regist_pasien.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                regist_pasienFocusGained(evt);
            }
        });
        regist_pasien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                regist_pasienMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                regist_pasienMouseExited(evt);
            }
        });
        regist_pasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regist_pasienActionPerformed(evt);
            }
        });
        jPanel59.add(regist_pasien, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 40));

        jPanel1.add(jPanel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 270, 40));

        jPanel99.setBackground(new java.awt.Color(0, 81, 120));
        jPanel99.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel100.setBackground(new java.awt.Color(0, 102, 153));
        jPanel100.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel99.add(jPanel100, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel101.setBackground(new java.awt.Color(0, 102, 153));
        jPanel101.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel102.setBackground(new java.awt.Color(0, 102, 153));
        jPanel102.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel101.add(jPanel102, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel99.add(jPanel101, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel103.setBackground(new java.awt.Color(0, 102, 153));
        jPanel103.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel104.setBackground(new java.awt.Color(0, 102, 153));
        jPanel104.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel103.add(jPanel104, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel105.setBackground(new java.awt.Color(0, 102, 153));
        jPanel105.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel106.setBackground(new java.awt.Color(0, 102, 153));
        jPanel106.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel105.add(jPanel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel103.add(jPanel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel99.add(jPanel103, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jLabel13.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Downloads\\[A gambar]\\Appointment.png")); // NOI18N
        jLabel13.setText("jLabel13");
        jPanel99.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 40, 40));

        create_channel.setBackground(new java.awt.Color(0, 81, 120));
        create_channel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        create_channel.setForeground(new java.awt.Color(255, 255, 255));
        create_channel.setText("            Create Appointment");
        create_channel.setBorderPainted(false);
        create_channel.setContentAreaFilled(false);
        create_channel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        create_channel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        create_channel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                create_channelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                create_channelMouseExited(evt);
            }
        });
        create_channel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_channelActionPerformed(evt);
            }
        });
        jPanel99.add(create_channel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 40));

        jPanel1.add(jPanel99, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, 270, 40));

        jPanel107.setBackground(new java.awt.Color(0, 81, 120));
        jPanel107.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel108.setBackground(new java.awt.Color(0, 102, 153));
        jPanel108.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel107.add(jPanel108, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel109.setBackground(new java.awt.Color(0, 102, 153));
        jPanel109.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel110.setBackground(new java.awt.Color(0, 102, 153));
        jPanel110.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel109.add(jPanel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel107.add(jPanel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel111.setBackground(new java.awt.Color(0, 102, 153));
        jPanel111.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel112.setBackground(new java.awt.Color(0, 102, 153));
        jPanel112.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel111.add(jPanel112, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel113.setBackground(new java.awt.Color(0, 102, 153));
        jPanel113.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel114.setBackground(new java.awt.Color(0, 102, 153));
        jPanel114.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel113.add(jPanel114, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel111.add(jPanel113, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel107.add(jPanel111, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jPanel115.setBackground(new java.awt.Color(0, 102, 153));
        jPanel115.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel116.setBackground(new java.awt.Color(0, 102, 153));
        jPanel116.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel115.add(jPanel116, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel117.setBackground(new java.awt.Color(0, 102, 153));
        jPanel117.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel118.setBackground(new java.awt.Color(0, 102, 153));
        jPanel118.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel117.add(jPanel118, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel115.add(jPanel117, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel119.setBackground(new java.awt.Color(0, 102, 153));
        jPanel119.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel120.setBackground(new java.awt.Color(0, 102, 153));
        jPanel120.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel119.add(jPanel120, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel121.setBackground(new java.awt.Color(0, 102, 153));
        jPanel121.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel122.setBackground(new java.awt.Color(0, 102, 153));
        jPanel122.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel121.add(jPanel122, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel119.add(jPanel121, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel115.add(jPanel119, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jPanel107.add(jPanel115, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 330, 220, 40));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/status.png"))); // NOI18N
        jPanel107.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 30, 40));

        view_doctor.setBackground(new java.awt.Color(0, 81, 120));
        view_doctor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        view_doctor.setForeground(new java.awt.Color(255, 255, 255));
        view_doctor.setText("            Status Appointment");
        view_doctor.setBorderPainted(false);
        view_doctor.setContentAreaFilled(false);
        view_doctor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        view_doctor.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        view_doctor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                view_doctorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                view_doctorMouseExited(evt);
            }
        });
        view_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view_doctorActionPerformed(evt);
            }
        });
        jPanel107.add(view_doctor, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 40));

        jPanel1.add(jPanel107, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, 270, 40));

        jPanel83.setBackground(new java.awt.Color(0, 81, 120));
        jPanel83.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel84.setBackground(new java.awt.Color(0, 102, 153));
        jPanel84.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel83.add(jPanel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel85.setBackground(new java.awt.Color(0, 102, 153));
        jPanel85.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel86.setBackground(new java.awt.Color(0, 102, 153));
        jPanel86.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel85.add(jPanel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel83.add(jPanel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel87.setBackground(new java.awt.Color(0, 102, 153));
        jPanel87.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel88.setBackground(new java.awt.Color(0, 102, 153));
        jPanel88.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel87.add(jPanel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel89.setBackground(new java.awt.Color(0, 102, 153));
        jPanel89.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel90.setBackground(new java.awt.Color(0, 102, 153));
        jPanel90.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel89.add(jPanel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel87.add(jPanel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel83.add(jPanel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jPanel91.setBackground(new java.awt.Color(0, 102, 153));
        jPanel91.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel92.setBackground(new java.awt.Color(0, 102, 153));
        jPanel92.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel91.add(jPanel92, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel93.setBackground(new java.awt.Color(0, 102, 153));
        jPanel93.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel94.setBackground(new java.awt.Color(0, 102, 153));
        jPanel94.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel93.add(jPanel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel91.add(jPanel93, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel95.setBackground(new java.awt.Color(0, 102, 153));
        jPanel95.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel96.setBackground(new java.awt.Color(0, 102, 153));
        jPanel96.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel95.add(jPanel96, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel97.setBackground(new java.awt.Color(0, 102, 153));
        jPanel97.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel98.setBackground(new java.awt.Color(0, 102, 153));
        jPanel98.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel97.add(jPanel98, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel95.add(jPanel97, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel91.add(jPanel95, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jPanel83.add(jPanel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 330, 220, 40));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Regist.png"))); // NOI18N
        jPanel83.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 40, 40));

        regist_doctor.setBackground(new java.awt.Color(0, 81, 120));
        regist_doctor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        regist_doctor.setForeground(new java.awt.Color(255, 255, 255));
        regist_doctor.setText("            Regist Doctor  ");
        regist_doctor.setBorderPainted(false);
        regist_doctor.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        regist_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regist_doctorActionPerformed(evt);
            }
        });
        jPanel83.add(regist_doctor, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 40));

        jPanel1.add(jPanel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 270, 270, 40));

        jPanel35.setBackground(new java.awt.Color(0, 81, 120));
        jPanel35.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/view-32.png"))); // NOI18N
        jPanel35.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 40, 40));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/registed.png"))); // NOI18N
        jPanel35.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 40, 40));

        jPanel36.setBackground(new java.awt.Color(0, 102, 153));
        jPanel36.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel35.add(jPanel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel37.setBackground(new java.awt.Color(0, 102, 153));
        jPanel37.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel38.setBackground(new java.awt.Color(0, 102, 153));
        jPanel38.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel37.add(jPanel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel35.add(jPanel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel39.setBackground(new java.awt.Color(0, 102, 153));
        jPanel39.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel40.setBackground(new java.awt.Color(0, 102, 153));
        jPanel40.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel39.add(jPanel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel41.setBackground(new java.awt.Color(0, 102, 153));
        jPanel41.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel42.setBackground(new java.awt.Color(0, 102, 153));
        jPanel42.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel41.add(jPanel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel39.add(jPanel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel35.add(jPanel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jPanel67.setBackground(new java.awt.Color(0, 102, 153));
        jPanel67.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel68.setBackground(new java.awt.Color(0, 102, 153));
        jPanel68.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel67.add(jPanel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel69.setBackground(new java.awt.Color(0, 102, 153));
        jPanel69.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel70.setBackground(new java.awt.Color(0, 102, 153));
        jPanel70.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel69.add(jPanel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel67.add(jPanel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel71.setBackground(new java.awt.Color(0, 102, 153));
        jPanel71.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel72.setBackground(new java.awt.Color(0, 102, 153));
        jPanel72.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel71.add(jPanel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel73.setBackground(new java.awt.Color(0, 102, 153));
        jPanel73.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel74.setBackground(new java.awt.Color(0, 102, 153));
        jPanel74.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel73.add(jPanel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel71.add(jPanel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel67.add(jPanel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jPanel35.add(jPanel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 330, 220, 40));

        registed_doctor.setBackground(new java.awt.Color(0, 81, 120));
        registed_doctor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        registed_doctor.setForeground(new java.awt.Color(255, 255, 255));
        registed_doctor.setText("            Registed Doctor");
        registed_doctor.setBorderPainted(false);
        registed_doctor.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        registed_doctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registed_doctorActionPerformed(evt);
            }
        });
        jPanel35.add(registed_doctor, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 40));

        View_appointment.setBackground(new java.awt.Color(0, 81, 120));
        View_appointment.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        View_appointment.setForeground(new java.awt.Color(255, 255, 255));
        View_appointment.setText("            View Appointment");
        View_appointment.setBorderPainted(false);
        View_appointment.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        View_appointment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                View_appointmentActionPerformed(evt);
            }
        });
        jPanel35.add(View_appointment, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 40));

        jPanel1.add(jPanel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 270, 40));

        jPanel51.setBackground(new java.awt.Color(0, 81, 120));
        jPanel51.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel52.setBackground(new java.awt.Color(0, 102, 153));
        jPanel52.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel51.add(jPanel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel53.setBackground(new java.awt.Color(0, 102, 153));
        jPanel53.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel54.setBackground(new java.awt.Color(0, 102, 153));
        jPanel54.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel53.add(jPanel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel51.add(jPanel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel55.setBackground(new java.awt.Color(0, 102, 153));
        jPanel55.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel56.setBackground(new java.awt.Color(0, 102, 153));
        jPanel56.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel55.add(jPanel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel57.setBackground(new java.awt.Color(0, 102, 153));
        jPanel57.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel58.setBackground(new java.awt.Color(0, 102, 153));
        jPanel58.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel57.add(jPanel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel55.add(jPanel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel51.add(jPanel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jPanel75.setBackground(new java.awt.Color(0, 102, 153));
        jPanel75.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel76.setBackground(new java.awt.Color(0, 102, 153));
        jPanel76.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel75.add(jPanel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel77.setBackground(new java.awt.Color(0, 102, 153));
        jPanel77.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel78.setBackground(new java.awt.Color(0, 102, 153));
        jPanel78.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel77.add(jPanel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel75.add(jPanel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel79.setBackground(new java.awt.Color(0, 102, 153));
        jPanel79.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel80.setBackground(new java.awt.Color(0, 102, 153));
        jPanel80.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel79.add(jPanel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel81.setBackground(new java.awt.Color(0, 102, 153));
        jPanel81.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel82.setBackground(new java.awt.Color(0, 102, 153));
        jPanel82.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel81.add(jPanel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel79.add(jPanel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel75.add(jPanel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jPanel51.add(jPanel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 280, 220, 40));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/registed.png"))); // NOI18N
        jPanel51.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 40, 40));

        registed_patient.setBackground(new java.awt.Color(0, 81, 120));
        registed_patient.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        registed_patient.setForeground(new java.awt.Color(255, 255, 255));
        registed_patient.setText("            Registed Patient");
        registed_patient.setBorderPainted(false);
        registed_patient.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        registed_patient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registed_patientActionPerformed(evt);
            }
        });
        jPanel51.add(registed_patient, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 40));

        jPanel1.add(jPanel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 370, 270, 40));

        jPanel43.setBackground(new java.awt.Color(0, 81, 120));
        jPanel43.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel44.setBackground(new java.awt.Color(0, 102, 153));
        jPanel44.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel43.add(jPanel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel45.setBackground(new java.awt.Color(0, 102, 153));
        jPanel45.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel46.setBackground(new java.awt.Color(0, 102, 153));
        jPanel46.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel45.add(jPanel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel43.add(jPanel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel47.setBackground(new java.awt.Color(0, 102, 153));
        jPanel47.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel48.setBackground(new java.awt.Color(0, 102, 153));
        jPanel48.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel47.add(jPanel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel49.setBackground(new java.awt.Color(0, 102, 153));
        jPanel49.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel50.setBackground(new java.awt.Color(0, 102, 153));
        jPanel50.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel49.add(jPanel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel47.add(jPanel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel43.add(jPanel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/registed.png"))); // NOI18N
        jPanel43.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 40, 40));

        user_admin.setBackground(new java.awt.Color(0, 81, 120));
        user_admin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        user_admin.setForeground(new java.awt.Color(255, 255, 255));
        user_admin.setText("            Registed User");
        user_admin.setBorderPainted(false);
        user_admin.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        user_admin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_adminActionPerformed(evt);
            }
        });
        jPanel43.add(user_admin, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 40));

        jPanel1.add(jPanel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 420, 270, 40));

        jPanel123.setBackground(new java.awt.Color(0, 81, 120));
        jPanel123.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel124.setBackground(new java.awt.Color(0, 102, 153));
        jPanel124.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel123.add(jPanel124, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel125.setBackground(new java.awt.Color(0, 102, 153));
        jPanel125.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel126.setBackground(new java.awt.Color(0, 102, 153));
        jPanel126.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel125.add(jPanel126, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel123.add(jPanel125, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel127.setBackground(new java.awt.Color(0, 102, 153));
        jPanel127.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel128.setBackground(new java.awt.Color(0, 102, 153));
        jPanel128.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel127.add(jPanel128, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel129.setBackground(new java.awt.Color(0, 102, 153));
        jPanel129.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel130.setBackground(new java.awt.Color(0, 102, 153));
        jPanel130.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel129.add(jPanel130, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel127.add(jPanel129, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel123.add(jPanel127, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 380, 220, 40));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/og out.png"))); // NOI18N
        jPanel123.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 30, 30));

        jButton6.setBackground(new java.awt.Color(0, 81, 120));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("            Log Out");
        jButton6.setBorderPainted(false);
        jButton6.setContentAreaFilled(false);
        jButton6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton6MouseExited(evt);
            }
        });
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel123.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 30));

        jPanel1.add(jPanel123, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 490, 270, 30));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/1AWallpaper.jpg"))); // NOI18N
        jLabel12.setText("jLabel12");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 540));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 270, 540));

        panel_utama.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(51, 0, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setForeground(new java.awt.Color(255, 255, 102));
        jLabel2.setText("Username");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 71, 145, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 102));
        jLabel3.setText("You are login as :");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 9, 145, -1));

        jLabel4.setForeground(new java.awt.Color(255, 255, 102));
        jLabel4.setText("Role");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 93, 145, -1));

        jButton5.setBackground(new java.awt.Color(0, 81, 120));
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Change");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(301, 6, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("jLabel5");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(181, 71, 85, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("jLabel6");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(181, 93, 85, -1));

        jComboBox1.setBackground(new java.awt.Color(214, 214, 214));
        jComboBox1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jComboBox1.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Active", "Deactive" }));
        jComboBox1.setToolTipText("");
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel2.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/1AWallpaper.jpg"))); // NOI18N
        jLabel8.setText("jLabel8");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 130));

        jPanel3.setBackground(new java.awt.Color(0, 102, 153));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(0, 102, 153));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel5.setBackground(new java.awt.Color(0, 102, 153));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(0, 102, 153));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel5.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 220, 40));

        jPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 220, 40));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-80, 60, -1, 40));

        panel_utama.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 390, 130));

        jLabel1.setFont(new java.awt.Font("Rockwell Condensed", 3, 48)); // NOI18N
        jLabel1.setText("Pet's Care");
        panel_utama.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 40, 203, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/download.jpg"))); // NOI18N
        jLabel7.setText(".");
        panel_utama.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 540));

        getContentPane().add(panel_utama, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 670, 540));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void registed_patientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registed_patientActionPerformed
                // TODO add your handling code here:
           if(userole.equals("Doctor")|| userole.equals("Admin"))
        {
            new Patient(idd,userole).setVisible(true);
            
        }
    }//GEN-LAST:event_registed_patientActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        

        if(userole.equals("Patient"))
        {
            login u = new login();
            this.setVisible(false);
            u.setVisible(true);
        }
        
        else if (userole.equals("Doctor"))
        {
            Connect();
        // Get the selected status from the jComboBox1
        String selectedStatus = jComboBox1.getSelectedItem().toString();

        try {
            // Update the status in the database
//            String updateQuery = "UPDATE doctor SET status = ? WHERE log_id = ?";
            pst = con.prepareStatement("UPDATE doctor SET status = ? WHERE log_id = ?");
            pst.setString(1, selectedStatus);
            pst.setInt(2, idd);

            int updatedRows = pst.executeUpdate();
            if(updatedRows > 0 && selectedStatus.equals("Active")) 
            {
                JOptionPane.showMessageDialog(this, "Status successfully changed to 'ACTIVE' ");
            } else if (updatedRows > 0 && selectedStatus.equals("Deactive"))
            {
                JOptionPane.showMessageDialog(this, "Status successfully changed to 'DEACTIVE' ");
            }

            else{
                JOptionPane.showMessageDialog(this, "Failed to update status");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    
        }
        
        

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
    int confirm = JOptionPane.showConfirmDialog(this, "Are you sure want to log out?", "Exit confirmation", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        login u = new login();
    this.setVisible(false);
    u.setVisible(true); 
    }
        
        
               // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void regist_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regist_doctorActionPerformed
        // TODO add your handling code here:
        
         if(userole.equals("Doctor")|| userole.equals("Admin"))
        {
            new Doctor(idd,uname,userole).setVisible(true);
            this.setVisible(false);
        }
            
    }//GEN-LAST:event_regist_doctorActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void create_channelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_channelActionPerformed
        if(userole.equals("Patient")|| userole.equals("Admin"))
        {
            new patient_channel(idd,userole).setVisible(true);
            
            
        }
    }//GEN-LAST:event_create_channelActionPerformed

    private void view_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view_doctorActionPerformed
        // TODO add your handling code here:
        new view_channel(idd).setVisible(true);
    }//GEN-LAST:event_view_doctorActionPerformed

    private void View_appointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_View_appointmentActionPerformed
        // TODO add your handling code here:
        
        new doctor_channel(idd).setVisible(true);
        
        
        
    }//GEN-LAST:event_View_appointmentActionPerformed

    private void regist_pasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regist_pasienActionPerformed
        if(userole.equals("Patient")|| userole.equals("Admin"))
        {

            new patient_regist(idd,uname,userole).setVisible(true);
            this.setVisible(false);

        }
    }//GEN-LAST:event_regist_pasienActionPerformed

    private void regist_pasienFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_regist_pasienFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_regist_pasienFocusGained

    private void registed_doctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registed_doctorActionPerformed
        // TODO add your handling code here:

        new doctor_list(idd,userole).setVisible(true);
    }//GEN-LAST:event_registed_doctorActionPerformed

    private void regist_pasienMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regist_pasienMouseEntered
        jPanel59.setBackground(new java.awt.Color(0, 61, 120));
    }//GEN-LAST:event_regist_pasienMouseEntered

    private void regist_pasienMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regist_pasienMouseExited
         jPanel59.setBackground(new java.awt.Color(0, 81, 120));
    }//GEN-LAST:event_regist_pasienMouseExited

    private void create_channelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_create_channelMouseEntered

                    boolean dataExists = checkDataExists(idd); // Mengembalikan true jika data ada

                if(dataExists) {
                    jPanel99.setBackground(new java.awt.Color(0, 61, 120));
                }
    }//GEN-LAST:event_create_channelMouseEntered

    private void create_channelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_create_channelMouseExited
        
        boolean dataExists = checkDataExists(idd); // Mengembalikan true jika data ada

        if(dataExists) {
            jPanel99.setBackground(new java.awt.Color(0, 81, 120));
        }
        
    }//GEN-LAST:event_create_channelMouseExited

    private void view_doctorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_view_doctorMouseEntered

        
        boolean dataExists = checkDataExists(idd); // Mengembalikan true jika data ada

        if(dataExists) {
                    jPanel107.setBackground(new java.awt.Color(0, 61, 120));
        }
    }//GEN-LAST:event_view_doctorMouseEntered

    private void view_doctorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_view_doctorMouseExited
        boolean dataExists = checkDataExists(idd); // Mengembalikan true jika data ada
        if(dataExists) {
                    jPanel107.setBackground(new java.awt.Color(0, 81, 120));
        }
    }//GEN-LAST:event_view_doctorMouseExited

    private void jButton6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseEntered
        jPanel123.setBackground(new java.awt.Color(0, 61, 120));
    }//GEN-LAST:event_jButton6MouseEntered

    private void jButton6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseExited
        jPanel123.setBackground(new java.awt.Color(0, 81, 120));
    }//GEN-LAST:event_jButton6MouseExited

    private void user_adminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_adminActionPerformed
        // TODO add your handling code here:
        
        new Registed_user_admin(idd,userole).setVisible(true);
        
    }//GEN-LAST:event_user_adminActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton View_appointment;
    private javax.swing.JButton create_channel;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel100;
    private javax.swing.JPanel jPanel101;
    private javax.swing.JPanel jPanel102;
    private javax.swing.JPanel jPanel103;
    private javax.swing.JPanel jPanel104;
    private javax.swing.JPanel jPanel105;
    private javax.swing.JPanel jPanel106;
    private javax.swing.JPanel jPanel107;
    private javax.swing.JPanel jPanel108;
    private javax.swing.JPanel jPanel109;
    private javax.swing.JPanel jPanel110;
    private javax.swing.JPanel jPanel111;
    private javax.swing.JPanel jPanel112;
    private javax.swing.JPanel jPanel113;
    private javax.swing.JPanel jPanel114;
    private javax.swing.JPanel jPanel115;
    private javax.swing.JPanel jPanel116;
    private javax.swing.JPanel jPanel117;
    private javax.swing.JPanel jPanel118;
    private javax.swing.JPanel jPanel119;
    private javax.swing.JPanel jPanel120;
    private javax.swing.JPanel jPanel121;
    private javax.swing.JPanel jPanel122;
    private javax.swing.JPanel jPanel123;
    private javax.swing.JPanel jPanel124;
    private javax.swing.JPanel jPanel125;
    private javax.swing.JPanel jPanel126;
    private javax.swing.JPanel jPanel127;
    private javax.swing.JPanel jPanel128;
    private javax.swing.JPanel jPanel129;
    private javax.swing.JPanel jPanel130;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel82;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel85;
    private javax.swing.JPanel jPanel86;
    private javax.swing.JPanel jPanel87;
    private javax.swing.JPanel jPanel88;
    private javax.swing.JPanel jPanel89;
    private javax.swing.JPanel jPanel90;
    private javax.swing.JPanel jPanel91;
    private javax.swing.JPanel jPanel92;
    private javax.swing.JPanel jPanel93;
    private javax.swing.JPanel jPanel94;
    private javax.swing.JPanel jPanel95;
    private javax.swing.JPanel jPanel96;
    private javax.swing.JPanel jPanel97;
    private javax.swing.JPanel jPanel98;
    private javax.swing.JPanel jPanel99;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JPanel panel_utama;
    private javax.swing.JButton regist_doctor;
    private javax.swing.JButton regist_pasien;
    private javax.swing.JButton registed_doctor;
    private javax.swing.JButton registed_patient;
    private javax.swing.JButton user_admin;
    private javax.swing.JButton view_doctor;
    // End of variables declaration//GEN-END:variables
}
